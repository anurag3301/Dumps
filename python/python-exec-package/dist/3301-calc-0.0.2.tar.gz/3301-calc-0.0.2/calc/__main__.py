# -*- coding: utf-8 -*-

from .calc import main
main()
