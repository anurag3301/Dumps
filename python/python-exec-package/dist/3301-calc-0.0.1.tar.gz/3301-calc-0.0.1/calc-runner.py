#!/usr/bin/env python
# -*- coding: utf-8 -*-

from calc.calc import main

if __name__ == "__main__":
    main()
