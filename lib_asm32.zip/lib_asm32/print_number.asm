section .text
    global print_number
    extern print_string

print_number:
    push ebp
    mov ebp, esp
    
    mov ecx, 10
    mov esi, buffer + 11
    mov byte [esi], 0
    
.next_digit:
    dec esi
    xor edx, edx
    div ecx
    add dl, '0'
    mov [esi], dl
    test eax, eax
    jnz .next_digit
    
    mov ecx, esi
    mov edx, buffer + 11
    sub edx, esi
    mov eax, 4
    mov ebx, 1
    int 0x80
    
    mov esp, ebp
    pop ebp
    ret

section .bss
    buffer resb 12
