section .text
    global my_memcpy

my_memcpy:
    push ebp
    mov ebp, esp
    push esi
    push edi
    
    mov edi, ecx
    mov esi, edx
    mov ecx, eax
    
    cld
    rep movsb
    
    mov eax, edi
    sub eax, ecx
    
    pop edi
    pop esi
    mov esp, ebp
    pop ebp
    ret
