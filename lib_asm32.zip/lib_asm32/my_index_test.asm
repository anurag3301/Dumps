section .text
    global my_index_test
    extern my_index, print_string, print_number

my_index_test:
    push 'o'
    push message
    call my_index
    add esp, 8

    push eax
    call print_string
    add esp, 4

    mov eax, 4
    mov ebx, 1
    mov ecx, newline
    mov edx, 1
    int 0x80

    ret

section .data
    message db "Hello, World!", 0
    newline db 10
