section .text
    global print_string

print_string:
    mov eax, 4
    mov ebx, 1
    int 0x80
    ret
