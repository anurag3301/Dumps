section .text
    global my_strchr_test
    extern my_strchr
    extern print_string

my_strchr_test:
    push ebp
    mov ebp, esp
    
    mov ecx, test_str
    mov edx, 'o'
    call my_strchr
    
    test eax, eax
    jz .not_found
    
    mov ecx, found_msg
    mov edx, found_msg_len
    call print_string
    
    jmp .done
    
.not_found:
    mov ecx, not_found_msg
    mov edx, not_found_msg_len
    call print_string
    
.done:
    mov esp, ebp
    pop ebp
    ret

section .data
    test_str db "Hello, World!", 0
    found_msg db "Character found!", 10, 0
    found_msg_len equ $ - found_msg
    not_found_msg db "Character not found!", 10, 0
    not_found_msg_len equ $ - not_found_msg
