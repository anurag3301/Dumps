section .text
    global my_memset

my_memset:
    push ebp
    mov ebp, esp
    push edi
    
    mov edi, ecx
    mov al, dl
    mov ecx, esi
    
    rep stosb
    
    mov eax, edi
    sub eax, esi
    
    pop edi
    mov esp, ebp
    pop ebp
    ret
