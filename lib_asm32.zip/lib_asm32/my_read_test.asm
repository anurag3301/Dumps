section .text
    global my_read_test
    extern my_read, my_write

my_read_test:
    push ebp
    mov ebp, esp
    sub esp, 256

    push 256
    lea eax, [ebp - 256]
    push eax
    push 0
    call my_read
    add esp, 12

    push eax
    lea eax, [ebp - 256]
    push eax
    push 1
    call my_write
    add esp, 12

    add esp, 256
    pop ebp
    ret
