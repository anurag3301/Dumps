section .text
    global my_memcpy_test
    extern my_memcpy
    extern print_string

my_memcpy_test:
    push ebp
    mov ebp, esp
    
    mov ecx, dst_buffer
    mov edx, src_buffer
    mov eax, 10
    call my_memcpy
    
    mov byte [dst_buffer + 10], 0
    
    mov ecx, test_msg
    mov edx, test_msg_len
    call print_string
    
    mov ecx, dst_buffer
    mov edx, 11
    call print_string
    
    mov esp, ebp
    pop ebp
    ret

section .data
    test_msg db "Memcpy test: ", 0
    test_msg_len equ $ - test_msg
    src_buffer db "0123456789", 0

section .bss
    dst_buffer resb 20
