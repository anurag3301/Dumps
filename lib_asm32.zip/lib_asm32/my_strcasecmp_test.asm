section .text
    global my_strcasecmp_test
    extern my_strcasecmp
    extern print_string
    extern print_number

my_strcasecmp_test:
    push ebp
    mov ebp, esp
    
    mov ecx, test1_msg
    mov edx, test1_msg_len
    call print_string
    
    mov ecx, str1
    mov edx, str2
    call my_strcasecmp
    
    call print_number
    
    mov ecx, newline
    mov edx, 1
    call print_string
    
    mov ecx, test2_msg
    mov edx, test2_msg_len
    call print_string
    
    mov ecx, str1
    mov edx, str3
    call my_strcasecmp
    
    call print_number
    
    mov ecx, newline
    mov edx, 1
    call print_string
    
    mov esp, ebp
    pop ebp
    ret

section .data
    test1_msg db "strcasecmp test 1 (same strings, different case): ", 0
    test1_msg_len equ $ - test1_msg
    test2_msg db "strcasecmp test 2 (different strings): ", 0
    test2_msg_len equ $ - test2_msg
    str1 db "Hello", 0
    str2 db "hELLo", 0
    str3 db "World", 0
    newline db 10, 0
