section .text
    global my_strcasecmp

my_strcasecmp:
    push ebp
    mov ebp, esp
    push esi
    push edi
    
    mov esi, ecx
    mov edi, edx
    
.loop:
    movzx eax, byte [esi]
    movzx ebx, byte [edi]
    
    ; Convert to lowercase if uppercase
    cmp eax, 'A'
    jb .skip_first
    cmp eax, 'Z'
    ja .skip_first
    add eax, 32
    
.skip_first:
    cmp ebx, 'A'
    jb .skip_second
    cmp ebx, 'Z'
    ja .skip_second
    add ebx, 32
    
.skip_second:
    cmp eax, ebx
    jne .not_equal
    
    test eax, eax
    jz .equal
    
    inc esi
    inc edi
    jmp .loop
    
.not_equal:
    sub eax, ebx
    jmp .done
    
.equal:
    xor eax, eax
    
.done:
    pop edi
    pop esi
    mov esp, ebp
    pop ebp
    ret
