section .text
    global my_memset_test
    extern my_memset
    extern print_string

my_memset_test:
    push ebp
    mov ebp, esp
    
    mov ecx, buffer
    mov dl, 'A'
    mov esi, 10
    call my_memset
    
    mov byte [buffer + 10], 0
    
    mov ecx, test_msg
    mov edx, test_msg_len
    call print_string
    
    mov ecx, buffer
    mov edx, 11
    call print_string
    
    mov esp, ebp
    pop ebp
    ret

section .data
    test_msg db "Memset test: ", 0
    test_msg_len equ $ - test_msg

section .bss
    buffer resb 20
