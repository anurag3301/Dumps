
section .text
    global _start
    extern my_strlen_test, my_strchr_test, my_memset_test, my_memcpy_test, my_strcmp_test, my_memmove_test
    extern my_strncmp_test, my_strcasecmp_test, my_index_test, my_read_test, my_write_test

_start:
    call my_strlen_test
    call my_strchr_test
    call my_memset_test
    call my_memcpy_test
    call my_strcmp_test
    call my_memmove_test
    call my_strncmp_test
    call my_strcasecmp_test
    call my_index_test
    call my_write_test
    call my_read_test

    mov eax, 1
    xor ebx, ebx
    int 0x80
