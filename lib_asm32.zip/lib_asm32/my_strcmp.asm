section .text
    global my_strcmp

my_strcmp:
    push ebp
    mov ebp, esp
    push esi
    push edi
    
    mov esi, ecx
    mov edi, edx
    
.loop:
    movzx eax, byte [esi]
    movzx ebx, byte [edi]
    
    cmp eax, ebx
    jne .not_equal
    
    test eax, eax
    jz .equal
    
    inc esi
    inc edi
    jmp .loop
    
.not_equal:
    sub eax, ebx
    jmp .done
    
.equal:
    xor eax, eax
    
.done:
    pop edi
    pop esi
    mov esp, ebp
    pop ebp
    ret
