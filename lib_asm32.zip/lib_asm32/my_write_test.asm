section .text
    global my_write_test
    extern my_write

my_write_test:
    push ebp
    mov ebp, esp

    push message_len
    push message
    push 1
    call my_write
    add esp, 12

    pop ebp
    ret

section .data
    message db "Hello from my_write_test!", 10, 0
    message_len equ $ - message - 1
