section .text
    global my_strncmp_test
    extern my_strncmp
    extern print_string
    extern print_number

my_strncmp_test:
    push ebp
    mov ebp, esp
    
    mov ecx, test1_msg
    mov edx, test1_msg_len
    call print_string
    
    mov ecx, str1
    mov edx, str2
    mov eax, 5
    call my_strncmp
    
    call print_number
    
    mov ecx, newline
    mov edx, 1
    call print_string
    
    mov ecx, test2_msg
    mov edx, test2_msg_len
    call print_string
    
    mov ecx, str1
    mov edx, str3
    mov eax, 3
    call my_strncmp
    
    call print_number
    
    mov ecx, newline
    mov edx, 1
    call print_string
    
    mov esp, ebp
    pop ebp
    ret

section .data
    test1_msg db "strncmp test 1 (same strings, n=5): ", 0
    test1_msg_len equ $ - test1_msg
    test2_msg db "strncmp test 2 (different strings, n=3): ", 0
    test2_msg_len equ $ - test2_msg
    str1 db "Hello", 0
    str2 db "Hello", 0
    str3 db "Help", 0
    newline db 10, 0
