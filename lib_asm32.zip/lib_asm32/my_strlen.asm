
section .text
    global my_strlen

my_strlen:
    push ebp
    mov ebp, esp
    mov ecx, -1
    mov edi, [ebp + 8]

.next_char:
    inc ecx
    cmp byte [edi + ecx], 0
    jne .next_char

    mov eax, ecx
    pop ebp
    ret
