section .text
    global my_read

my_read:
    push ebp
    mov ebp, esp
    mov eax, 3
    mov ebx, [ebp + 8]
    mov ecx, [ebp + 12]
    mov edx, [ebp + 16]
    int 0x80
    pop ebp
    ret
