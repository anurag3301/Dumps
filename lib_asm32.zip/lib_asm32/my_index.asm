section .text
    global my_index

my_index:
    push ebp
    mov ebp, esp
    mov edi, [ebp + 8]
    mov al, [ebp + 12]

.next_char:
    mov cl, [edi]
    cmp cl, al
    je .found
    cmp cl, 0
    je .not_found
    inc edi
    jmp .next_char

.found:
    mov eax, edi
    pop ebp
    ret

.not_found:
    xor eax, eax
    pop ebp
    ret
