section .text
    global my_memmove_test
    extern my_memmove
    extern print_string

my_memmove_test:
    push ebp
    mov ebp, esp
    
    mov ecx, test_msg1
    mov edx, test_msg1_len
    call print_string
    
    mov ecx, dst_buffer
    mov edx, src_buffer
    mov eax, 10
    call my_memmove
    
    mov byte [dst_buffer + 10], 0
    mov ecx, dst_buffer
    mov edx, 11
    call print_string
    
    mov ecx, newline
    mov edx, 1
    call print_string
    
    mov ecx, test_msg2
    mov edx, test_msg2_len
    call print_string
    
    mov edi, overlap_buffer
    mov esi, src_buffer
    mov ecx, 10
    rep movsb
    
    mov ecx, overlap_buffer + 3
    mov edx, overlap_buffer
    mov eax, 7
    call my_memmove
    
    mov byte [overlap_buffer + 10], 0
    mov ecx, overlap_buffer
    mov edx, 11
    call print_string
    
    mov esp, ebp
    pop ebp
    ret

section .data
    test_msg1 db "Memmove test (non-overlapping): ", 0
    test_msg1_len equ $ - test_msg1
    test_msg2 db "Memmove test (overlapping): ", 0
    test_msg2_len equ $ - test_msg2
    src_buffer db "0123456789", 0
    newline db 10, 0

section .bss
    dst_buffer resb 20
    overlap_buffer resb 20
