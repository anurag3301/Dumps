
section .text
    global my_strlen_test
    extern my_strlen, print_string, print_number

my_strlen_test:
    push message
    call my_strlen
    add esp, 4

    push eax
    call print_number
    add esp, 4

    mov eax, 4
    mov ebx, 1
    mov ecx, newline
    mov edx, 1
    int 0x80

    ret

section .data
    message db "Hello, World!", 0
    newline db 10
