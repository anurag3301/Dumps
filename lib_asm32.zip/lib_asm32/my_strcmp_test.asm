section .text
    global my_strcmp_test
    extern my_strcmp
    extern print_string
    extern print_number

my_strcmp_test:
    push ebp
    mov ebp, esp
    
    mov ecx, str1_msg
    mov edx, str1_msg_len
    call print_string
    
    mov ecx, str1
    mov edx, str2
    call my_strcmp
    
    call print_number
    
    mov ecx, newline
    mov edx, 1
    call print_string
    
    mov esp, ebp
    pop ebp
    ret

section .data
    str1_msg db "strcmp result: ", 0
    str1_msg_len equ $ - str1_msg
    str1 db "Hello", 0
    str2 db "Hello", 0
    newline db 10, 0
