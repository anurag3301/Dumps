section .text
    global my_strncmp

my_strncmp:
    push ebp
    mov ebp, esp
    push esi
    push edi
    
    mov esi, ecx
    mov edi, edx
    mov ecx, eax
    
    test ecx, ecx
    jz .equal
    
.loop:
    movzx eax, byte [esi]
    movzx ebx, byte [edi]
    
    test eax, eax
    jz .check_second
    
    cmp eax, ebx
    jne .not_equal
    
    test ebx, ebx
    jz .equal
    
    inc esi
    inc edi
    dec ecx
    jz .equal
    jmp .loop
    
.check_second:
    test ebx, ebx
    jz .equal
    
.not_equal:
    sub eax, ebx
    jmp .done
    
.equal:
    xor eax, eax
    
.done:
    pop edi
    pop esi
    mov esp, ebp
    pop ebp
    ret
