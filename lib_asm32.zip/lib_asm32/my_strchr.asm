section .text
    global my_strchr

my_strchr:
    push ebp
    mov ebp, esp
    push esi
    push edi
    
    mov esi, ecx
    
.loop:
    movzx eax, byte [esi]
    cmp al, dl
    je .found
    test al, al
    jz .not_found
    inc esi
    jmp .loop
    
.found:
    mov eax, esi
    jmp .done
    
.not_found:
    xor eax, eax
    
.done:
    pop edi
    pop esi
    mov esp, ebp
    pop ebp
    ret
