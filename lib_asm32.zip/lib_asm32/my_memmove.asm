section .text
    global my_memmove

my_memmove:
    push ebp
    mov ebp, esp
    push esi
    push edi
    
    mov edi, ecx
    mov esi, edx
    mov ecx, eax
    
    cmp edi, esi
    je .done
    jb .forward
    
    add esi, ecx
    add edi, ecx
    std
    sub esi, 1
    sub edi, 1
    rep movsb
    cld
    jmp .done
    
.forward:
    cld
    rep movsb
    
.done:
    mov eax, edi
    sub eax, ecx
    
    pop edi
    pop esi
    mov esp, ebp
    pop ebp
    ret
